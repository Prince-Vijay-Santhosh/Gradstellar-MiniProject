import sqlite3
conn=sqlite3.connect('OnlineBookstore.db')
c=conn.cursor()

def sold_books():
    Bookname = input("ENTER THE BOOKNAME:")
    No_of_books = int(input("ENTER NUMBER OF BOOKS:"))
    c.execute("select NO_OF_BOOKS from Available_books where Bookname='"+Bookname+"'")
    t=c.fetchone()
    if t is None:
        print("--------------------------BOOKS ARE NOT AVAILABLE(SOLD OUT)-------------------------")
    else:
        c.execute("insert into Sold_books values('"+Bookname+"','"+str(No_of_books)+"')")
        c.execute("update Available_books set No_of_books=No_of_books-'"+str(No_of_books)+"' where Bookname='"+Bookname+"'")
        conn.commit()
        print("""------------------------BOOK HAS BEEN SOLD----------------------""")

conn.commit()