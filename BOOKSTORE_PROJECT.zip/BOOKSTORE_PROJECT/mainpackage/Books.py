import mainpackage as main
import mainpackage.subpack1 as p1
import mainpackage.subpack2 as p2
import mainpackage.subpack3 as p3

from mainpackage.subpack1 import availablebooks as a
from mainpackage.subpack2 import soldbooks as b
from mainpackage.subpack3 import Display_data as c

print(main.mainpackage())
while True:
    print('''1.ADD BOOKS
             2. SELL BOOKS
             3. DISPLAY BOOKS
             4. EXIT ''')
    print("Choose an option from the menu:")
    ch=int(input("Enter Your Choice:"))
    if ch==1:
        a.avail_books()
    elif ch==2:
        b.sold_books()
    elif ch==3:
        c.display()
    elif ch==4:
        print("-----------------------THANKYOU FOR VISITING !! KEEP SHOPPING--------------------------------")
        break
