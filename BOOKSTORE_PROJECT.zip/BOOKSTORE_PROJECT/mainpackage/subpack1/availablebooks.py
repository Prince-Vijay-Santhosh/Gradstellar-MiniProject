import sqlite3
conn=sqlite3.connect('OnlineBookstore.db')
c=conn.cursor()

def avail_books():
    print("ENTER THE BELOW DETAILS")
    Bookname=input("ENTER THE BOOKNAME:")
    Genre=input("ENTER GENRE OF THE BOOK:")
    No_of_books=int(input("ENTER NUMBER OF BOOKS:"))
    Author=input("ENTER THE AUTHOR OF THE BOOK:")
    Publication=input("ENTER THE PUBLICATIONS NAME:")
    Price=int(input("ENTER THE PRICE:"))

    row=c.fetchone()
    if row is None:
        c.execute(
            "insert into Available_books(Bookname,Genre,No_of_books,Author,Publication,Price) values('" + Bookname + "','" + Genre + "','"
            + str(No_of_books) + "','" + Author + "','" + Publication + "','" + str(Price) + "')")
        conn.commit()
        print("""-----------------DATA SUCCESSFULLY ADDED---------------------""")

    else:
        c.execute("update Available_books set No_of_books=No_of_books+'"+str(No_of_books)+"' where Bookname='"+Bookname+"'")
        conn.commit()
        print("""-----------------DATA SUCCESSFULLY ADDED---------------------""")

