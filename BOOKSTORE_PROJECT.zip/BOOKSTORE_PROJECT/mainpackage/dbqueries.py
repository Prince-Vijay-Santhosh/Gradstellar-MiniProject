import sqlite3
conn=sqlite3.connect('OnlineBookstore.db')
#query to create a table to list available books
query1=''' create table Available_books( BOOKNAME text not null,GENRE text not null,NO_OF_BOOKS int not null,AUTHOR text
not null,PUBLICATION text not null,PRICE int not null )'''
conn.execute(query1)

#query to create a table to list available books
query2=''' create table Sold_books(BOOKNAME text not null ,NO_OF_BOOKS
int not null , foreign key(BOOKNAME) references add_books(BOOKNAME))'''

conn.execute(query2)
