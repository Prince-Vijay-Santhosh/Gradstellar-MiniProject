import sqlite3
conn= sqlite3.connect('OnlineBookstore.db')
c = conn.cursor()

def display():
    print("AVAILABLE BOOKS IN THE STORE ARE")
    s=c.execute("select * from Available_books")
    for i in s:
        print(i)
conn.commit()