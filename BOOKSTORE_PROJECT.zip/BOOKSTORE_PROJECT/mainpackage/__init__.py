def mainpackage():
    return "WELCOME TO ONLINE BOOKSTORE"